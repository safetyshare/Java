package com.advanced.project.db;

import com.advanced.db.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class select {
    public static void selectall() {
        try(Connection con= ConnectionFactory.getConnection()){
            String sql="select * from jdbc.student";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs=stmt.executeQuery();
//        5.操作 ResultSet 结果集
            while (rs.next()){
                String sid= rs.getString("sid");
                String sname=rs.getString("sname");
                String sclass=rs.getString("sclass");
                String address=rs.getString("address");
                String teleNumber=rs.getString("teleNumber");
                String QQ=rs.getString("QQ");
                System.out.println("学号："+sid+"\t姓名："+sname+"\t班级："+sclass+"\t地址："+address+"\t电话："+teleNumber+"\tQQ号："+QQ);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
    public static void selectStudentBySID(String sid) {
        try(Connection con= ConnectionFactory.getConnection()){
            String sql="select * from jdbc.student where sid=?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,sid);
            ResultSet rs=stmt.executeQuery();
//        5.操作 ResultSet 结果集
            while (rs.next()){
//                String sid= rs.getString("sid");
                String sname=rs.getString("sname");
                String sclass=rs.getString("sclass");
                String address=rs.getString("address");
                String teleNumber=rs.getString("teleNumber");
                String QQ=rs.getString("QQ");
                System.out.println("学号："+sid+"\t姓名："+sname+"\t班级："+sclass+"\t地址："+address+"\t电话："+teleNumber+"\tQQ号："+QQ);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void selectStudentByName(String sname) {
        try(Connection con= ConnectionFactory.getConnection()){
            String sql="select * from jdbc.student where sname=?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,sname);
            ResultSet rs=stmt.executeQuery();
//        5.操作 ResultSet 结果集
            while (rs.next()){
                String sid= rs.getString("sid");
//                String sname=rs.getString("sname");
                String sclass=rs.getString("sclass");
                String address=rs.getString("address");
                String teleNumber=rs.getString("teleNumber");
                String QQ=rs.getString("QQ");
                System.out.println("学号："+sid+"\t姓名："+sname+"\t班级："+sclass+"\t地址："+address+"\t电话："+teleNumber+"\tQQ号："+QQ);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
