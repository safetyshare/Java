package com.advanced.project.dao.impl;

import com.advanced.project.bean.Student;
import com.advanced.project.dao.StudentDao;
import com.advanced.project.db.*;
import java.util.List;

public class StudentDaoImpl implements StudentDao {

    @Override
    public List<Student> lookAllStudent() {
        select.selectall();
        return List.of();
    }

    @Override
    public boolean addStudent(Student student) {
        Insert.insert(student);
        return false;
    }

    @Override
    public Student lookStudentById(String sid) {
        select.selectStudentBySID(sid);
        return null;
    }

    @Override
    public List<Student> lookStudentByName(String sname) {
        select.selectStudentByName(sname);
        return List.of();
    }

    @Override
    public boolean updateStudent(Student student) {
        update.Update(student);
        return false;
    }

    @Override
    public boolean deleteStudent(String sid) {
        delete.deleteSid(sid);
        return false;
    }
}
